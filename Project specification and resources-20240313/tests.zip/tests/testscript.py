import subprocess, threading, os
import cases

MAIN_PATH = "./"
BIN_PATH = "bin/"
SRC_PATH = "src/"
OUT_PATH = "out/"
TEST_PATH = "tests/"
INPUT_PATH = "input/"

CLASS_NAME = "Translate"


class Command:
    def __init__(self, cmd, cwd="./"):
        self.cmd = cmd
        self.cwd = cwd
        self.process = None

    def run(self, timeout=300):
        def target():
            self.process = subprocess.Popen(
                self.cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                cwd=self.cwd,
                shell=True,
            )
            self.out, self.err = self.process.communicate()

        thread = threading.Thread(target=target)
        thread.start()

        thread.join(timeout)
        if thread.is_alive():
            self.process.terminate()
            thread.join()
            err = "A Timeout occurred!"
        else:
            err = self.err.decode("utf-8")

        return self.process.returncode, self.out.decode("utf-8"), err


def compile_code(src_path, bin_path, out_path):
    cmd = Command("mkdir -p {}".format(bin_path), "./")
    cmd.run()
    cmd = Command("rm -f *.class", bin_path)
    cmd.run()
    cmd = Command("mkdir -p {}".format(out_path), "./")
    cmd.run()

    cmd = Command("javac -d {} {}*.java".format(bin_path, src_path), "./")
    sig, out, err = cmd.run()

    if sig != 0:
        print("COMPILATION ERROR")
        print(">>>>>>>> OUT >>>>>>>>")
        print(out)
        print(">>>>>>>> ERR >>>>>>>>")
        print(err)
        print("COMPILATION ERROR")
        return False

    return True


# populates arrays for test cases and corresponding outputs
def parse_tests(mode, input_path, output_path):
    tests = []
    expected_out = []
    actual_out = []

    if mode == "level1_t2b":
        for s in cases.LEVEL1_T2B:
            tests.append(input_path + s)

            # user's output should be in "out/test_t2b.brf"
            output_file = os.path.splitext(s)[0] + "_t2b.brf"
            actual_out.append(output_path + output_file)

            # expected output to compare is in "tests/input/test.brf"
            expected_file = os.path.splitext(s)[0] + ".brf"
            expected_out.append(input_path + expected_file)

    elif mode == "level1_b2t":
        for s in cases.LEVEL1_B2T:
            tests.append(input_path + s)

            # user's output should be in "out/test_b2t.txt"
            output_file = os.path.splitext(s)[0] + "_b2t.txt"
            actual_out.append(output_path + output_file)

            # expected output to compare is in "tests/input/test.txt"
            expected_file = os.path.splitext(s)[0] + ".txt"
            expected_out.append(input_path + expected_file)

    return tests, actual_out, expected_out


# compares actual and expected outputs of test cases
def run_tests(mode, tests, actual_out, expected_out):
    GREEN = "\033[92m"
    RED = "\033[91m"
    RESET = "\033[0m"

    correct_count = 0
    total_count = len(tests)

    for test, actual, expected in zip(tests, actual_out, expected_out):
        if mode == "level1_t2b":
            cmd = Command(
                "java -cp {} {} noGUI {} {} {}".format(
                    BIN_PATH, CLASS_NAME, "t2b", "1", test
                )
            )
            sig, out, err = cmd.run()

        passed = compare_files(actual, expected)

        if passed:
            print(GREEN + "✔", test + RESET)
            correct_count += 1
        else:
            print(RED + "X", test + RESET)

    return (correct_count, total_count)


def compare_files(actual_file, expected_file):
    try:
        with open(actual_file, "r") as actual, open(expected_file, "r") as expected:
            actual_text = actual.read().strip()
            expected_text = expected.read().strip()
            return actual_text == expected_text

    except FileNotFoundError:
        return False


def main():
    if not compile_code(SRC_PATH, BIN_PATH, OUT_PATH):
        print("Compilation failed")
        return

    input_path = TEST_PATH + INPUT_PATH
    output_path = MAIN_PATH + OUT_PATH

    results = {}

    tests, actual_out, expected_out = parse_tests("level1_t2b", input_path, output_path)
    val = run_tests("level1_t2b", tests, actual_out, expected_out)
    results["level1_t2b"] = val

    tests, actual_out, expected_out = parse_tests("level1_b2t", input_path, output_path)
    val = run_tests("level1_b2t", tests, actual_out, expected_out)
    results["level1_b2t"] = val

    overall_correct = 0
    overall_total = 0
    print("RESULTS:")
    for i in results.keys():
        correct, total = results[i]
        overall_total += total
        overall_correct += correct
        print("{}: {} / {} CORRECT".format(i, correct, total))

    print("OVERALL: {} / {} CORRECT".format(overall_correct, overall_total))


if __name__ == "__main__":
    main()
