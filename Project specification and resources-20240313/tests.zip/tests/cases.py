LEVEL1_T2B = [
    "Test1Level1.0.txt",
    "Test2Level1.0.txt",
    "Test3Level1.0.txt",
]

LEVEL1_B2T = [
    "Test1Level1.0.brf",
    "Test2Level1.0.brf",
    "Test3Level1.0.brf",
]
